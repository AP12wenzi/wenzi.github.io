export type Emoji = {
  name: string;
  url: string;
};
